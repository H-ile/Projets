# RésaVite

Bienvenue dans l'application RésaVite.

## Base de données

La base s'appelle "resavite". Son login est "root" et il n'y a pas de password.

## Login et password

Tous les login ont été créés. Voici la liste.
* bob
* douglas
* jef
* carlos
* marie
* helena
* peter
* olga

Les password sont le login + 31. Par exemple, c'est bob31 pour le login bob.

Enjoy !

Signé : le stagiaire de la compta.