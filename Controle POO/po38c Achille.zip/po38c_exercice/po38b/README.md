# po38b

Exercice sur la base de données "fortune".

## Import 

Utilise un fichier EXCEL à transformer en CSV avant import

## Accès aux données

Utilise la base de données avec classe métier et DAO.
