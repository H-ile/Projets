<?php
/**
 * Menu de l'application
 */
?>
<ul>
  <li>Page d'<a href="index.php">accueil</a></li>
  <li><a href="google.php">Rechercher une fortune</a></li>
  
</ul>